/**
 * Required Libraries:
 * npm install express cors body-parser sqlite3 node-telegram-bot-api
 */

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const TelegramBot = require('node-telegram-bot-api');

// --- CONFIGURATION ---
const USER_BOT_TOKEN = 'YOUR_USER_BOT_TOKEN_HERE';
const ADMIN_BOT_TOKEN = 'YOUR_ADMIN_BOT_TOKEN_HERE';
const ADMIN_USER_ID = 123456789; // Replace with your actual Telegram User ID
const PORT = 3001;
const WEB_APP_URL = 'http://localhost:5173'; // URL where your React app runs

// --- DATABASE SETUP ---
const db = new sqlite3.Database('./casino.db', (err) => {
    if (err) console.error(err.message);
    console.log('Connected to the casino database.');
});

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        balance INTEGER DEFAULT 0,
        banned INTEGER DEFAULT 0,
        joined_at TEXT
    )`);
});

// --- EXPRESS SERVER ---
const app = express();
app.use(cors());
app.use(bodyParser.json());

// API: Get Balance
app.get('/api/balance/:id', (req, res) => {
    const id = req.params.id;
    db.get("SELECT balance, banned FROM users WHERE id = ?", [id], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!row) return res.status(404).json({ error: "User not found" });
        if (row.banned) return res.status(403).json({ error: "Banned" });
        res.json({ balance: row.balance });
    });
});

// API: Update Balance (Game Result)
app.post('/api/updateBalance', (req, res) => {
    const { uid, amount } = req.body;
    db.run("UPDATE users SET balance = balance + ? WHERE id = ?", [amount, uid], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true });
    });
});

// --- USER BOT ---
const userBot = new TelegramBot(USER_BOT_TOKEN, { polling: true });

userBot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || "Guest";
    
    // Register user if not exists
    db.run("INSERT OR IGNORE INTO users (id, username, balance, joined_at) VALUES (?, ?, ?, ?)", 
        [chatId, username, 0, new Date().toISOString()], 
        (err) => {
            if (err) console.error(err);
            
            const opts = {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🎰 Играть (Login)', url: `${WEB_APP_URL}?uid=${chatId}` }
                        ],
                        [
                            { text: '💰 Пополнить (Бесплатно)', callback_data: 'topup' },
                            { text: '👤 Профиль', callback_data: 'profile' }
                        ]
                    ]
                }
            };
            userBot.sendMessage(chatId, `Привет, ${username}! Добро пожаловать в Казино Рояль Флеш.\nЗдесь нет ИИ, только удача.`, opts);
        }
    );
});

userBot.on('callback_query', (callbackQuery) => {
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const data = callbackQuery.data;

    if (data === 'topup') {
        db.run("UPDATE users SET balance = balance + 1000 WHERE id = ?", [chatId], (err) => {
            if (err) return;
            userBot.answerCallbackQuery(callbackQuery.id, { text: 'Баланс пополнен на $1000!' });
            userBot.sendMessage(chatId, "Ваш баланс пополнен на $1000. Удачной игры!");
        });
    } else if (data === 'profile') {
        db.get("SELECT * FROM users WHERE id = ?", [chatId], (err, row) => {
            if (row) {
                userBot.sendMessage(chatId, `👤 **Профиль**\n\nID: ${row.id}\nБаланс: $${row.balance}\nСтатус: ${row.banned ? '⛔ ЗАБАНЕН' : '✅ Активен'}`);
            }
        });
    }
});

// --- ADMIN BOT ---
const adminBot = new TelegramBot(ADMIN_BOT_TOKEN, { polling: true });

// Check Admin Middleware
const isAdmin = (msg) => msg.from.id === ADMIN_USER_ID;

adminBot.onText(/\/start/, (msg) => {
    if (!isAdmin(msg)) return;
    adminBot.sendMessage(msg.chat.id, "Админ панель:\n/users - Список пользователей\n/info [id] - Инфо о юзере\n/add [id] [сумма] - Добавить баланс\n/ban [id] - Забанить\n/unban [id] - Разбанить");
});

adminBot.onText(/\/users/, (msg) => {
    if (!isAdmin(msg)) return;
    db.all("SELECT id, username, balance FROM users LIMIT 20", [], (err, rows) => {
        if (err) return;
        let response = "Список пользователей:\n";
        rows.forEach(row => {
            response += `${row.id} | ${row.username} | $${row.balance}\n`;
        });
        adminBot.sendMessage(msg.chat.id, response || "Нет пользователей");
    });
});

adminBot.onText(/\/add (\d+) (-?\d+)/, (msg, match) => {
    if (!isAdmin(msg)) return;
    const userId = match[1];
    const amount = parseInt(match[2]);
    db.run("UPDATE users SET balance = balance + ? WHERE id = ?", [amount, userId], function(err) {
        if (this.changes > 0) {
            adminBot.sendMessage(msg.chat.id, `Баланс пользователя ${userId} изменен на ${amount}`);
            userBot.sendMessage(userId, `Администратор изменил ваш баланс на ${amount}.`);
        } else {
            adminBot.sendMessage(msg.chat.id, "Пользователь не найден");
        }
    });
});

adminBot.onText(/\/ban (\d+)/, (msg, match) => {
    if (!isAdmin(msg)) return;
    const userId = match[1];
    db.run("UPDATE users SET banned = 1 WHERE id = ?", [userId], function(err) {
        adminBot.sendMessage(msg.chat.id, `Пользователь ${userId} забанен.`);
    });
});

adminBot.onText(/\/unban (\d+)/, (msg, match) => {
    if (!isAdmin(msg)) return;
    const userId = match[1];
    db.run("UPDATE users SET banned = 0 WHERE id = ?", [userId], function(err) {
        adminBot.sendMessage(msg.chat.id, `Пользователь ${userId} разбанен.`);
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Backend running on port ${PORT}`);
});