// This logic is combined in server.js for easier execution,
// but if you need a separate file, copy the "USER BOT" section from server.js here.
console.log("Please run server.js to start both bots and the API");