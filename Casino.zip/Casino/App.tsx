import React, { useState, useEffect } from 'react';
import { GameType } from './types';
import Slots from './components/games/Slots';
import Blackjack from './components/games/Blackjack';
import Roulette from './components/games/Roulette';
import VideoPoker from './components/games/VideoPoker';
import Rocket from './components/games/Rocket';
import { Dice1, Spade, CircleDollarSign, LayoutGrid, Menu, X, Wallet, Club, History, Trash2, Rocket as RocketIcon, Lock } from 'lucide-react';
import { playSound } from './utils/sound';
import { getHistory, clearHistory } from './utils/storage';

const App: React.FC = () => {
  const [activeGame, setActiveGame] = useState<GameType>(GameType.HOME);
  const [balance, setBalance] = useState(0); 
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [historyItems, setHistoryItems] = useState(getHistory());
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // URL адрес твоего Python сервера в Pydroid 3 (обычно localhost)
  const API_URL = 'http://127.0.0.1:5000';

  // Auth & Initial Balance Check
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const uid = params.get('uid');

    if (uid) {
        setUserId(uid);
        fetchBalance(uid);
    } else {
        setLoading(false);
    }
  }, []);

  const fetchBalance = async (uid: string) => {
      try {
          const response = await fetch(`${API_URL}/balance/${uid}`);
          if (response.ok) {
              const data = await response.json();
              setBalance(data.balance);
          } else {
              // Fallback to local if server offline
              const saved = localStorage.getItem(`balance_${uid}`);
              setBalance(saved ? parseInt(saved) : 0);
          }
      } catch (e) {
          // Server offline or CORS issue
          const saved = localStorage.getItem(`balance_${uid}`);
          setBalance(saved ? parseInt(saved) : 0);
      } finally {
          setLoading(false);
      }
  };

  const updateBalance = async (amount: number) => {
    // Optimistic update
    setBalance(prev => {
        const newBal = prev + amount;
        if (userId) localStorage.setItem(`balance_${userId}`, newBal.toString());
        return newBal;
    });

    if (userId) {
        try {
            await fetch(`${API_URL}/update`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ uid: userId, amount })
            });
        } catch (e) {
            console.error("Failed to sync with bot server");
        }
    }
  };

  const toggleHistory = () => {
      if (!showHistory) {
          setHistoryItems(getHistory());
      }
      setShowHistory(!showHistory);
      setIsSidebarOpen(false);
  };

  const handleClearHistory = () => {
      clearHistory();
      setHistoryItems([]);
  };

  const navItems = [
    { id: GameType.HOME, label: 'Лобби', icon: <LayoutGrid size={20} /> },
    { id: GameType.SLOTS, label: 'Слоты', icon: <Dice1 size={20} /> },
    { id: GameType.BLACKJACK, label: 'Блэкджек', icon: <Spade size={20} /> },
    { id: GameType.ROULETTE, label: 'Рулетка', icon: <CircleDollarSign size={20} /> },
    { id: GameType.VIDEO_POKER, label: 'Видеопокер', icon: <Club size={20} /> },
    { id: GameType.ROCKET, label: 'Ракета', icon: <RocketIcon size={20} /> },
  ];

  const renderGame = () => {
    switch (activeGame) {
      case GameType.SLOTS:
        return <Slots balance={balance} updateBalance={updateBalance} onBack={() => setActiveGame(GameType.HOME)} />;
      case GameType.BLACKJACK:
        return <Blackjack balance={balance} updateBalance={updateBalance} onBack={() => setActiveGame(GameType.HOME)} />;
      case GameType.ROULETTE:
        return <Roulette balance={balance} updateBalance={updateBalance} onBack={() => setActiveGame(GameType.HOME)} />;
      case GameType.VIDEO_POKER:
        return <VideoPoker balance={balance} updateBalance={updateBalance} onBack={() => setActiveGame(GameType.HOME)} />;
      case GameType.ROCKET:
        return <Rocket balance={balance} updateBalance={updateBalance} onBack={() => setActiveGame(GameType.HOME)} />;
      case GameType.HOME:
      default:
        return (
          <div className="w-full max-w-7xl mx-auto p-6 animate-in zoom-in-95 duration-500">
             <div className="text-center mb-12">
                <h1 className="text-5xl md:text-7xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-b from-[#e5b168] via-[#fcd34d] to-[#b45309] mb-4 drop-shadow-[0_4px_4px_rgba(0,0,0,0.5)]">
                   КАЗИНО РОЯЛЬ
                </h1>
                <p className="text-slate-400 text-xl tracking-[0.3em] uppercase font-light border-b border-slate-800 inline-block pb-4">Добро пожаловать</p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
                <div 
                    onClick={() => { playSound('click'); setActiveGame(GameType.SLOTS); }}
                    className="group relative h-80 bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-yellow-600/30 border border-white/5 transition-all duration-300 hover:-translate-y-2"
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent z-10"></div>
                    <img src="https://images.unsplash.com/photo-1596838132731-3301c3fd4317?auto=format&fit=crop&q=80&w=800" alt="Slots" className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
                    <div className="absolute bottom-0 left-0 p-4 z-20 w-full">
                        <h3 className="text-xl font-bold text-white mb-1 drop-shadow-md">Слоты</h3>
                        <div className="bg-yellow-500 w-8 h-8 rounded-full flex items-center justify-center text-black shadow-lg absolute right-4 bottom-4">
                            <Dice1 size={16} />
                        </div>
                    </div>
                </div>

                <div 
                    onClick={() => { playSound('click'); setActiveGame(GameType.BLACKJACK); }}
                    className="group relative h-80 bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-blue-600/30 border border-white/5 transition-all duration-300 hover:-translate-y-2"
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent z-10"></div>
                    <img src="https://images.unsplash.com/photo-1605870445919-838d190e8e1b?auto=format&fit=crop&q=80&w=800" alt="Blackjack" className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
                    <div className="absolute bottom-0 left-0 p-4 z-20 w-full">
                        <h3 className="text-xl font-bold text-white mb-1 drop-shadow-md">Блэкджек</h3>
                        <div className="bg-blue-600 w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg absolute right-4 bottom-4">
                            <Spade size={16} />
                        </div>
                    </div>
                </div>

                <div 
                    onClick={() => { playSound('click'); setActiveGame(GameType.ROULETTE); }}
                    className="group relative h-80 bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-red-600/30 border border-white/5 transition-all duration-300 hover:-translate-y-2"
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent z-10"></div>
                    <img src="https://images.unsplash.com/photo-1606167668584-78701c57f13d?auto=format&fit=crop&q=80&w=800" alt="Roulette" className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
                    <div className="absolute bottom-0 left-0 p-4 z-20 w-full">
                        <h3 className="text-xl font-bold text-white mb-1 drop-shadow-md">Рулетка</h3>
                        <div className="bg-red-600 w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg absolute right-4 bottom-4">
                            <CircleDollarSign size={16} />
                        </div>
                    </div>
                </div>

                <div 
                    onClick={() => { playSound('click'); setActiveGame(GameType.VIDEO_POKER); }}
                    className="group relative h-80 bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-purple-600/30 border border-white/5 transition-all duration-300 hover:-translate-y-2"
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent z-10"></div>
                    <img src="https://images.unsplash.com/photo-1511193311914-0346f16efe90?auto=format&fit=crop&q=80&w=800" alt="Video Poker" className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
                    <div className="absolute bottom-0 left-0 p-4 z-20 w-full">
                        <h3 className="text-xl font-bold text-white mb-1 drop-shadow-md">Видеопокер</h3>
                        <div className="bg-purple-600 w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg absolute right-4 bottom-4">
                            <Club size={16} />
                        </div>
                    </div>
                </div>

                 <div 
                    onClick={() => { playSound('click'); setActiveGame(GameType.ROCKET); }}
                    className="group relative h-80 bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-orange-600/30 border border-white/5 transition-all duration-300 hover:-translate-y-2"
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent z-10"></div>
                    <img src="https://images.unsplash.com/photo-1517976487492-5750f3195933?auto=format&fit=crop&q=80&w=800" alt="Rocket" className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
                    <div className="absolute bottom-0 left-0 p-4 z-20 w-full">
                        <h3 className="text-xl font-bold text-white mb-1 drop-shadow-md">Ракета</h3>
                        <div className="bg-orange-600 w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg absolute right-4 bottom-4">
                            <RocketIcon size={16} />
                        </div>
                    </div>
                </div>

             </div>
          </div>
        );
    }
  };

  if (!userId && !loading) {
      return (
          <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4">
              <div className="max-w-md w-full bg-slate-900 rounded-2xl p-8 border border-slate-700 shadow-2xl text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full mx-auto flex items-center justify-center mb-6 shadow-lg shadow-yellow-500/20">
                      <Lock className="text-black" size={32} />
                  </div>
                  <h1 className="text-3xl font-serif font-bold text-white mb-4">Вход в Казино</h1>
                  <p className="text-slate-400 mb-8">
                      Чтобы получить доступ, пожалуйста, запустите нашего Telegram бота.
                  </p>
                  <a href="https://t.me/YOUR_BOT_USERNAME" className="block w-full py-4 bg-[#229ED9] hover:bg-[#1b85b8] text-white font-bold rounded-xl transition-colors">
                      Открыть Бот
                  </a>
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-slate-100 flex flex-col md:flex-row overflow-hidden font-sans selection:bg-yellow-500/30">
      
      {/* Mobile Header */}
      <div className="md:hidden bg-slate-950 p-4 flex justify-between items-center border-b border-white/5 z-50">
          <span className="font-serif font-bold text-xl text-[#e5b168]">РОЯЛЬ ФЛЕШ</span>
          <button onClick={() => { playSound('click'); setIsSidebarOpen(!isSidebarOpen); }} className="p-2 text-white">
              {isSidebarOpen ? <X /> : <Menu />}
          </button>
      </div>

      {/* Sidebar Navigation */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-slate-950 border-r border-white/5 transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 flex flex-col
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
         <div className="p-8 hidden md:block">
            <h2 className="text-2xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#e5b168] to-[#b45309] tracking-wider">РОЯЛЬ ФЛЕШ</h2>
         </div>

         <nav className="p-4 space-y-2 flex-1">
            {navItems.map(item => (
                <button
                    key={item.id}
                    onClick={() => {
                        playSound('click');
                        setActiveGame(item.id);
                        setIsSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-4 px-4 py-3 rounded-lg transition-all font-medium text-sm tracking-wide ${activeGame === item.id ? 'bg-[#e5b168] text-black shadow-[0_0_15px_rgba(229,177,104,0.3)]' : 'text-slate-400 hover:bg-slate-900 hover:text-white'}`}
                >
                    {item.icon}
                    {item.label}
                </button>
            ))}
            <button
                onClick={() => { playSound('click'); toggleHistory(); }}
                className="w-full flex items-center gap-4 px-4 py-3 rounded-lg transition-all font-medium text-sm tracking-wide text-slate-400 hover:bg-slate-900 hover:text-white"
            >
                <History size={20} />
                История Игр
            </button>
         </nav>

         <div className="p-6 bg-slate-950 border-t border-white/5">
             <div className="bg-slate-900 rounded-xl p-5 border border-white/5 shadow-inner">
                 <div className="text-slate-500 text-[10px] font-bold uppercase mb-2 flex items-center gap-2">
                     <Wallet size={12} /> Ваш Баланс
                 </div>
                 <div className="text-3xl font-mono text-[#4ade80] font-bold flex items-center mb-3">
                     $ {balance.toLocaleString()}
                 </div>
                 <div className="text-[10px] text-slate-500 text-center">
                     Пополнять через Telegram
                 </div>
             </div>
         </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#1a1a1a] via-[#0a0a0a] to-black relative">
         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-leather.png')] opacity-10 pointer-events-none"></div>
         <div className="relative z-10 w-full min-h-full flex flex-col">
            {/* Top Bar (Desktop) */}
            <div className="hidden md:flex justify-end p-6 items-center gap-4">
                 {userId && <span className="text-slate-500 text-xs">ID: {userId}</span>}
                 <div className="flex items-center gap-2 px-4 py-2 bg-black/40 rounded-full border border-white/5 backdrop-blur-sm">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_#22c55e]"></div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Онлайн</span>
                 </div>
            </div>

            {/* Game Render */}
            <div className="flex-1 flex items-center justify-center p-4">
                {renderGame()}
            </div>
         </div>
      </main>

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/80 z-30 md:hidden backdrop-blur-sm"
            onClick={() => setIsSidebarOpen(false)}
          ></div>
      )}

      {/* History Modal */}
      {showHistory && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-slate-900 w-full max-w-2xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
                  <div className="p-6 border-b border-white/5 flex justify-between items-center bg-slate-950">
                      <h2 className="text-xl font-bold text-white flex items-center gap-2">
                          <History className="text-yellow-500" /> История Ставок
                      </h2>
                      <div className="flex gap-2">
                        <button onClick={handleClearHistory} className="p-2 hover:bg-red-900/30 text-red-400 rounded-lg transition-colors" title="Очистить историю">
                            <Trash2 size={20} />
                        </button>
                        <button onClick={toggleHistory} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                            <X size={20} />
                        </button>
                      </div>
                  </div>
                  <div className="overflow-y-auto p-0 flex-1">
                      {historyItems.length === 0 ? (
                          <div className="p-12 text-center text-slate-500">
                              История пуста. Сделайте ставку!
                          </div>
                      ) : (
                          <table className="w-full text-left border-collapse">
                              <thead className="bg-slate-950 sticky top-0">
                                  <tr>
                                      <th className="p-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Игра</th>
                                      <th className="p-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Результат</th>
                                      <th className="p-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Ставка</th>
                                      <th className="p-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Выплата</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-white/5">
                                  {historyItems.map((item) => (
                                      <tr key={item.id} className="hover:bg-white/5 transition-colors">
                                          <td className="p-4 text-sm font-medium text-white">
                                              {item.gameType === GameType.SLOTS ? 'Слоты' : 
                                               item.gameType === GameType.BLACKJACK ? 'Блэкджек' : 
                                               item.gameType === GameType.ROULETTE ? 'Рулетка' : 
                                               item.gameType === GameType.ROCKET ? 'Ракета' : 'Видеопокер'}
                                              <div className="text-xs text-slate-500 mt-1">{new Date(item.timestamp).toLocaleTimeString()}</div>
                                          </td>
                                          <td className="p-4 text-sm text-slate-300">
                                              {item.result}
                                          </td>
                                          <td className="p-4 text-sm font-mono text-slate-400 text-right">
                                              ${item.betAmount}
                                          </td>
                                          <td className={`p-4 text-sm font-mono font-bold text-right ${item.payout > 0 ? 'text-green-400' : 'text-slate-500'}`}>
                                              {item.payout > 0 ? `+$${item.payout}` : '-'}
                                          </td>
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      )}
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

export default App;