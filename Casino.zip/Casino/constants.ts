import { Card, SlotSymbol, RouletteNumber } from './types';
import React from 'react';

// --- SLOTS ---
export const SLOT_SYMBOLS: SlotSymbol[] = [
  { id: 1, icon: '🍒', value: 2, color: 'text-red-500' },
  { id: 2, icon: '🍋', value: 3, color: 'text-yellow-400' },
  { id: 3, icon: '🍇', value: 5, color: 'text-purple-500' },
  { id: 4, icon: '🔔', value: 10, color: 'text-yellow-600' },
  { id: 5, icon: '💎', value: 20, color: 'text-blue-400' },
  { id: 6, icon: '7️⃣', value: 50, color: 'text-red-600' },
  { id: 7, icon: '👑', value: 100, color: 'text-yellow-300' },
];

// --- CARDS ---
export const SUITS = ['hearts', 'diamonds', 'clubs', 'spades'] as const;
export const VALUES = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

export const createDeck = (): Card[] => {
  const deck: Card[] = [];
  SUITS.forEach(suit => {
    VALUES.forEach(value => {
      let numericValue = parseInt(value);
      if (['J', 'Q', 'K'].includes(value)) numericValue = 10;
      if (value === 'A') numericValue = 11;
      deck.push({ suit, value, numericValue });
    });
  });
  return shuffleDeck(deck);
};

export const shuffleDeck = (deck: Card[]): Card[] => {
  const newDeck = [...deck];
  for (let i = newDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
  }
  return newDeck;
};

// --- ROULETTE ---
export const ROULETTE_NUMBERS: RouletteNumber[] = [
  { number: 0, color: 'green' },
  { number: 32, color: 'red' },
  { number: 15, color: 'black' },
  { number: 19, color: 'red' },
  { number: 4, color: 'black' },
  { number: 21, color: 'red' },
  { number: 2, color: 'black' },
  { number: 25, color: 'red' },
  { number: 17, color: 'black' },
  { number: 34, color: 'red' },
  { number: 6, color: 'black' },
  { number: 27, color: 'red' },
  { number: 13, color: 'black' },
  { number: 36, color: 'red' },
  { number: 11, color: 'black' },
  { number: 30, color: 'red' },
  { number: 8, color: 'black' },
  { number: 23, color: 'red' },
  { number: 10, color: 'black' },
  { number: 5, color: 'red' },
  { number: 24, color: 'black' },
  { number: 16, color: 'red' },
  { number: 33, color: 'black' },
  { number: 1, color: 'red' },
  { number: 20, color: 'black' },
  { number: 14, color: 'red' },
  { number: 31, color: 'black' },
  { number: 9, color: 'red' },
  { number: 22, color: 'black' },
  { number: 18, color: 'red' },
  { number: 29, color: 'black' },
  { number: 7, color: 'red' },
  { number: 28, color: 'black' },
  { number: 12, color: 'red' },
  { number: 35, color: 'black' },
  { number: 3, color: 'red' },
  { number: 26, color: 'black' }
];
