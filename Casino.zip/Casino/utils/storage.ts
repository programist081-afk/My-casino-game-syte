import { GameHistoryItem } from '../types';

const HISTORY_KEY = 'casino_history';

export const addToHistory = (item: Omit<GameHistoryItem, 'id' | 'timestamp'>) => {
  const history = getHistory();
  const newItem: GameHistoryItem = {
    ...item,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
  };
  // Keep last 50 items
  const updatedHistory = [newItem, ...history].slice(0, 50);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
};

export const getHistory = (): GameHistoryItem[] => {
  try {
    const stored = localStorage.getItem(HISTORY_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("Failed to parse history", e);
    return [];
  }
};

export const clearHistory = () => {
    localStorage.removeItem(HISTORY_KEY);
};