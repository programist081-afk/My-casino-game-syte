export enum GameType {
  SLOTS = 'SLOTS',
  BLACKJACK = 'BLACKJACK',
  ROULETTE = 'ROULETTE',
  VIDEO_POKER = 'VIDEO_POKER',
  ROCKET = 'ROCKET',
  HOME = 'HOME'
}

export interface Card {
  suit: 'hearts' | 'diamonds' | 'clubs' | 'spades';
  value: string; // '2', '3', ..., '10', 'J', 'Q', 'K', 'A'
  numericValue: number;
}

export interface SlotSymbol {
  id: number;
  icon: string;
  value: number;
  color: string;
}

export interface RouletteNumber {
  number: number;
  color: 'red' | 'black' | 'green';
}

export interface GameHistoryItem {
  id: string;
  timestamp: number;
  gameType: GameType;
  betAmount: number;
  result: string;
  payout: number;
  balanceAfter: number;
}