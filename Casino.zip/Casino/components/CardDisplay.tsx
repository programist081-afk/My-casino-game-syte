import React from 'react';
import { Card } from '../types';
import { Heart, Diamond, Club, Spade } from 'lucide-react';

interface CardDisplayProps {
  card: Card;
  hidden?: boolean;
  className?: string;
}

const CardDisplay: React.FC<CardDisplayProps> = ({ card, hidden = false, className = '' }) => {
  const isRed = card.suit === 'hearts' || card.suit === 'diamonds';
  
  const getIcon = () => {
    switch (card.suit) {
      case 'hearts': return <Heart className="w-4 h-4 fill-current" />;
      case 'diamonds': return <Diamond className="w-4 h-4 fill-current" />;
      case 'clubs': return <Club className="w-4 h-4 fill-current" />;
      case 'spades': return <Spade className="w-4 h-4 fill-current" />;
    }
  };

  if (hidden) {
    return (
      <div className={`w-24 h-36 bg-red-800 rounded-lg border-2 border-white/20 shadow-xl flex items-center justify-center relative overflow-hidden ${className}`}>
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-yellow-500 to-transparent"></div>
        <div className="w-20 h-32 border-2 border-dashed border-red-900/50 rounded flex items-center justify-center">
            <span className="text-4xl text-red-950 font-serif font-bold">R</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`w-24 h-36 bg-white rounded-lg border border-gray-300 shadow-xl flex flex-col justify-between p-2 select-none transform hover:-translate-y-2 transition-transform duration-200 ${className}`}>
      <div className={`text-left font-bold text-xl ${isRed ? 'text-red-600' : 'text-slate-900'} flex flex-col items-center w-6`}>
        <span>{card.value}</span>
        {getIcon()}
      </div>
      <div className={`text-center text-4xl ${isRed ? 'text-red-600' : 'text-slate-900'}`}>
        {getIcon()}
      </div>
      <div className={`text-right font-bold text-xl ${isRed ? 'text-red-600' : 'text-slate-900'} flex flex-col items-center w-6 self-end rotate-180`}>
        <span>{card.value}</span>
        {getIcon()}
      </div>
    </div>
  );
};

export default CardDisplay;