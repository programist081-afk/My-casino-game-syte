import React, { useState, useEffect } from 'react';
import { Card, GameType } from '../../types';
import { createDeck } from '../../constants';
import CardDisplay from '../CardDisplay';
import { Hand, StopCircle, Play, ArrowLeft, RefreshCcw } from 'lucide-react';
import { playSound } from '../../utils/sound';
import { addToHistory } from '../../utils/storage';

interface BlackjackProps {
  balance: number;
  updateBalance: (amount: number) => void;
  onBack: () => void;
}

type GameState = 'betting' | 'playing' | 'dealerTurn' | 'gameOver';

const Blackjack: React.FC<BlackjackProps> = ({ balance, updateBalance, onBack }) => {
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [gameState, setGameState] = useState<GameState>('betting');
  const [bet, setBet] = useState(50);
  const [message, setMessage] = useState("Сделайте ставку");

  useEffect(() => {
    setDeck(createDeck());
  }, []);

  const calculateScore = (hand: Card[]) => {
    let score = 0;
    let aces = 0;
    hand.forEach(card => {
      score += card.numericValue;
      if (card.value === 'A') aces += 1;
    });
    while (score > 21 && aces > 0) {
      score -= 10;
      aces -= 1;
    }
    return score;
  };

  const dealGame = () => {
    if (balance < bet) {
      setMessage("Недостаточно фишек!");
      playSound('lose');
      return;
    }
    
    playSound('chip');
    let currentDeck = [...deck];
    if (currentDeck.length < 15) {
        currentDeck = createDeck();
    }

    const pHand = [currentDeck.pop()!, currentDeck.pop()!];
    const dHand = [currentDeck.pop()!, currentDeck.pop()!];
    
    // Simulate card deal sounds
    playSound('card');
    setTimeout(() => playSound('card'), 200);
    setTimeout(() => playSound('card'), 400);
    setTimeout(() => playSound('card'), 600);

    setDeck(currentDeck);
    setPlayerHand(pHand);
    setDealerHand(dHand);
    updateBalance(-bet);
    
    const pScore = calculateScore(pHand);
    if (pScore === 21) {
        setGameState('gameOver');
        setMessage("Блэкджек! Вы выиграли!");
        const winAmount = bet * 2.5;
        updateBalance(winAmount);
        playSound('win');
        addToHistory({
            gameType: GameType.BLACKJACK,
            betAmount: bet,
            result: 'Блэкджек',
            payout: winAmount,
            balanceAfter: balance - bet + winAmount
        });
    } else {
        setGameState('playing');
        setMessage("Ваш ход: Взять или Хватит?");
    }
  };

  const hit = () => {
    playSound('card');
    const newDeck = [...deck];
    const card = newDeck.pop()!;
    setDeck(newDeck);
    const newHand = [...playerHand, card];
    setPlayerHand(newHand);
    
    if (calculateScore(newHand) > 21) {
      setGameState('gameOver');
      setMessage("Перебор! Дилер выиграл.");
      playSound('lose');
      addToHistory({
          gameType: GameType.BLACKJACK,
          betAmount: bet,
          result: 'Перебор',
          payout: 0,
          balanceAfter: balance // already deducted
      });
    }
  };

  const stand = () => {
    playSound('click');
    setGameState('dealerTurn');
  };

  useEffect(() => {
    if (gameState === 'dealerTurn') {
        let currentDealerHand = [...dealerHand];
        let currentDeck = [...deck];
        let dScore = calculateScore(currentDealerHand);

        const playDealer = async () => {
            while (dScore < 17) {
                await new Promise(r => setTimeout(r, 800));
                playSound('card');
                const card = currentDeck.pop()!;
                currentDealerHand = [...currentDealerHand, card];
                setDealerHand(currentDealerHand);
                setDeck(currentDeck);
                dScore = calculateScore(currentDealerHand);
            }
            
            finishGame(calculateScore(playerHand), dScore);
        };
        playDealer();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameState]);

  const finishGame = (pScore: number, dScore: number) => {
    setGameState('gameOver');
    let winAmount = 0;
    let resultMsg = "";
    
    if (dScore > 21) {
        resultMsg = "Дилер перебрал! Вы выиграли!";
        winAmount = bet * 2;
        playSound('win');
    } else if (pScore > dScore) {
        resultMsg = "Победа!";
        winAmount = bet * 2;
        playSound('win');
    } else if (pScore === dScore) {
        resultMsg = "Ничья. Ставка возвращена.";
        winAmount = bet;
        playSound('chip');
    } else {
        resultMsg = "Дилер выиграл.";
        winAmount = 0;
        playSound('lose');
    }

    setMessage(resultMsg);
    if (winAmount > 0) updateBalance(winAmount);
    
    addToHistory({
        gameType: GameType.BLACKJACK,
        betAmount: bet,
        result: dScore > 21 ? 'Победа (Дилер перебрал)' : pScore > dScore ? 'Победа' : pScore === dScore ? 'Ничья' : 'Проигрыш',
        payout: winAmount,
        balanceAfter: balance + winAmount // balance prop is from start of hand? No, balance prop is updated by updateBalance(-bet) at start.
    });
  };

  return (
    <div className="flex flex-col items-center w-full max-w-6xl mx-auto p-4 animate-in fade-in duration-500">
      <button onClick={() => { playSound('click'); onBack(); }} className="self-start mb-4 flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft size={20} /> Меню
      </button>

      <div className="w-full bg-[#0a3318] rounded-[4rem] p-4 md:p-12 border-[16px] border-[#3e2723] shadow-2xl relative min-h-[650px] flex flex-col justify-between overflow-hidden">
        {/* Table Felt Texture */}
        <div className="absolute inset-0 rounded-[3rem] border border-white/5 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/felt.png')] opacity-50"></div>
        
        {/* Logo on table */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-10 pointer-events-none">
            <div className="text-6xl font-serif font-bold text-black whitespace-nowrap">BLACKJACK</div>
        </div>

        {/* Dealer Area */}
        <div className="flex flex-col items-center mb-8 relative z-10">
          <div className="bg-black/20 px-4 py-1 rounded-full mb-4 backdrop-blur-sm border border-white/5">
            <h3 className="text-green-100/80 uppercase font-bold tracking-widest text-xs">Дилер</h3>
          </div>
          <div className="flex gap-2 md:gap-4 h-32 md:h-40 items-center justify-center">
             {dealerHand.map((card, i) => (
                <div key={i} className={`transform transition-all duration-500 ${i===1 && gameState === 'playing' ? 'translate-y-2' : ''}`}>
                   <CardDisplay 
                     card={card} 
                     hidden={i === 1 && gameState === 'playing'} 
                     className="shadow-xl"
                   />
                </div>
             ))}
             {dealerHand.length === 0 && <div className="w-24 h-36 border-2 border-dashed border-white/10 rounded-lg"></div>}
          </div>
          {gameState === 'gameOver' && (
              <div className="mt-2 bg-black/60 px-3 py-1 rounded-full text-white font-mono border border-white/10">
                  {calculateScore(dealerHand)}
              </div>
          )}
        </div>

        {/* Center Info */}
        <div className="flex flex-col items-center justify-center my-4 relative z-10 min-h-[60px]">
           <div className={`text-xl md:text-2xl font-serif font-bold px-8 py-3 rounded-full border border-white/10 backdrop-blur-md shadow-lg transition-all ${
               gameState === 'gameOver' 
               ? message.includes('выиграли') || message.includes('Победа') ? 'bg-yellow-500/90 text-black' : 'bg-red-900/80 text-white'
               : 'bg-black/40 text-white'
           }`}>
               {message}
           </div>
        </div>

        {/* Player Area */}
        <div className="flex flex-col items-center mt-4 relative z-10">
            <div className="flex gap-2 md:gap-4 h-32 md:h-40 items-center justify-center mb-4 pl-8">
                {playerHand.map((card, i) => (
                    <div key={i} className="transform -ml-8 hover:-translate-y-4 transition-transform duration-200">
                    <CardDisplay card={card} className="shadow-2xl" />
                    </div>
                ))}
                {playerHand.length === 0 && <div className="w-24 h-36 border-2 border-dashed border-white/10 rounded-lg ml-8"></div>}
            </div>
             {playerHand.length > 0 && (
              <div className="mb-4 bg-black/60 px-3 py-1 rounded-full text-white font-mono border border-white/10">
                  {calculateScore(playerHand)}
              </div>
            )}
            <div className="bg-black/20 px-4 py-1 rounded-full backdrop-blur-sm border border-white/5">
                <h3 className="text-green-100/80 uppercase font-bold tracking-widest text-xs">Вы</h3>
            </div>
        </div>

        {/* Controls */}
        <div className="mt-6 bg-black/40 p-4 rounded-3xl border border-white/10 flex items-center justify-between gap-4 backdrop-blur-md z-10 shadow-xl">
            
            {gameState === 'betting' || gameState === 'gameOver' ? (
                <div className="flex flex-col md:flex-row w-full justify-between items-center gap-4">
                    <div className="flex flex-col md:flex-row items-center gap-4">
                         <span className="text-green-100 font-bold uppercase text-xs tracking-wider">Ставка</span>
                         <div className="flex gap-3">
                             {[10, 50, 100, 500].map(amt => (
                                 <button
                                    key={amt}
                                    onClick={() => { playSound('chip'); setBet(amt); }}
                                    className={`w-12 h-12 rounded-full border-4 border-dashed font-bold flex items-center justify-center transition-all hover:scale-110 shadow-lg ${bet === amt ? 'bg-yellow-500 border-yellow-300 text-black scale-110' : 'bg-slate-800 border-slate-600 text-slate-300'}`}
                                 >
                                     {amt}
                                 </button>
                             ))}
                         </div>
                    </div>
                    <button 
                        onClick={dealGame}
                        disabled={balance < bet}
                        className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white px-10 py-3 rounded-full font-bold uppercase tracking-widest shadow-lg flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95"
                    >
                        {gameState === 'gameOver' ? <RefreshCcw size={20} /> : <Play size={20} fill="currentColor" />}
                        {gameState === 'gameOver' ? 'Играть снова' : 'Раздать'}
                    </button>
                </div>
            ) : (
                <div className="flex w-full justify-center gap-4 md:gap-8">
                     <button 
                        onClick={hit}
                        disabled={gameState !== 'playing'}
                        className="bg-blue-600 hover:bg-blue-500 text-white px-8 md:px-12 py-4 rounded-full font-bold uppercase tracking-wider shadow-lg flex items-center gap-3 disabled:opacity-50 transition-all hover:-translate-y-1 active:scale-95 border-b-4 border-blue-800 active:border-b-0 active:translate-y-1"
                    >
                        <Hand size={24} /> Взять
                    </button>
                    <button 
                        onClick={stand}
                        disabled={gameState !== 'playing'}
                        className="bg-yellow-500 hover:bg-yellow-400 text-black px-8 md:px-12 py-4 rounded-full font-bold uppercase tracking-wider shadow-lg flex items-center gap-3 disabled:opacity-50 transition-all hover:-translate-y-1 active:scale-95 border-b-4 border-yellow-700 active:border-b-0 active:translate-y-1"
                    >
                        <StopCircle size={24} /> Хватит
                    </button>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default Blackjack;