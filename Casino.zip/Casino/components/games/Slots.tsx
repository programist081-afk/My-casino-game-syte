import React, { useState } from 'react';
import { SLOT_SYMBOLS } from '../../constants';
import { SlotSymbol, GameType } from '../../types';
import { RefreshCw, Trophy, ArrowLeft } from 'lucide-react';
import { playSound } from '../../utils/sound';
import { addToHistory } from '../../utils/storage';

interface SlotsProps {
  balance: number;
  updateBalance: (amount: number) => void;
  onBack: () => void;
}

const Slots: React.FC<SlotsProps> = ({ balance, updateBalance, onBack }) => {
  const [reels, setReels] = useState<SlotSymbol[]>([SLOT_SYMBOLS[0], SLOT_SYMBOLS[1], SLOT_SYMBOLS[2]]);
  const [spinning, setSpinning] = useState(false);
  const [bet, setBet] = useState(10);
  const [lastWin, setLastWin] = useState(0);
  const [message, setMessage] = useState("Сделайте ставку и крутите!");

  const spin = () => {
    if (spinning) return;
    if (balance < bet) {
      setMessage("Недостаточно средств!");
      playSound('lose');
      return;
    }

    const currentBalance = balance - bet;
    playSound('click');
    updateBalance(-bet);
    setSpinning(true);
    setMessage("Удачи...");
    setLastWin(0);

    // Simulate spin duration
    let spins = 0;
    const interval = setInterval(() => {
      setReels([
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]
      ]);
      playSound('spin');
      spins++;
      if (spins > 20) {
        clearInterval(interval);
        finalizeSpin(currentBalance);
      }
    }, 100);
  };

  const finalizeSpin = (balanceAfterBet: number) => {
    const finalReels = [
      SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
      SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
      SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]
    ];
    setReels(finalReels);
    setSpinning(false);
    checkWin(finalReels, balanceAfterBet);
  };

  const checkWin = (result: SlotSymbol[], balanceAfterBet: number) => {
    let winAmount = 0;
    let resultMsg = "Проигрыш";

    if (result[0].id === result[1].id && result[1].id === result[2].id) {
      winAmount = bet * result[0].value;
      updateBalance(winAmount);
      setLastWin(winAmount);
      setMessage(`ДЖЕКПОТ! Вы выиграли $${winAmount}!`);
      playSound('win');
      resultMsg = `Джекпот (${result[0].value}x)`;
    } 
    else if (result[0].id === result[1].id || result[1].id === result[2].id || result[0].id === result[2].id) {
      const matchedSymbol = result[0].id === result[1].id ? result[0] : result[2];
      winAmount = Math.floor(bet * (matchedSymbol.value / 4));
      if (winAmount > 0) {
        updateBalance(winAmount);
        setLastWin(winAmount);
        setMessage(`Отлично! Пара совпала. Выигрыш: $${winAmount}`);
        playSound('win');
        resultMsg = "Пара";
      } else {
         setMessage("Близко! Попробуйте еще раз.");
         playSound('click');
         resultMsg = "Пара (без выигрыша)";
      }
    } else {
      setMessage("Не повезло. Крутите снова!");
    }

    addToHistory({
        gameType: GameType.SLOTS,
        betAmount: bet,
        result: resultMsg,
        payout: winAmount,
        balanceAfter: balanceAfterBet + winAmount
    });
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[600px] w-full max-w-4xl mx-auto p-4 animate-in fade-in duration-500">
      
      <button onClick={() => { playSound('click'); onBack(); }} className="self-start mb-4 flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft size={20} /> Назад в меню
      </button>

      <div className="bg-gradient-to-b from-slate-900 to-black p-8 rounded-3xl shadow-2xl border-4 border-yellow-600 w-full max-w-2xl relative overflow-hidden">
        {/* Decorative background image overlay */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/black-scales.png')] opacity-30 pointer-events-none"></div>

        {/* Decorative Lights */}
        <div className="absolute top-2 left-2 right-2 flex justify-between px-4 z-10">
            <div className={`w-3 h-3 rounded-full ${spinning ? 'animate-pulse bg-yellow-300 shadow-[0_0_10px_#fde047]' : 'bg-yellow-800'}`}></div>
            <div className={`w-3 h-3 rounded-full ${spinning ? 'animate-pulse bg-yellow-300 shadow-[0_0_10px_#fde047]' : 'bg-yellow-800'}`}></div>
            <div className={`w-3 h-3 rounded-full ${spinning ? 'animate-pulse bg-yellow-300 shadow-[0_0_10px_#fde047]' : 'bg-yellow-800'}`}></div>
        </div>

        <div className="mb-8 text-center mt-4 relative z-10">
          <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-100 to-yellow-500 tracking-wider font-serif drop-shadow-md">
            ЗОЛОТЫЕ СЛОТЫ
          </h2>
          <p className="text-yellow-100/80 mt-2 font-medium h-6 text-lg">{message}</p>
        </div>

        {/* Reels Container */}
        <div className="flex gap-2 md:gap-4 justify-center items-center bg-black/80 p-6 rounded-xl border-4 border-yellow-700 shadow-[inset_0_0_20px_rgba(0,0,0,0.8)] mb-8 relative z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/60 pointer-events-none z-20 rounded-lg"></div>
          {reels.map((symbol, index) => (
            <div key={index} className="w-24 md:w-32 h-36 md:h-44 bg-slate-100 rounded-lg flex items-center justify-center text-5xl md:text-6xl shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)] border-2 border-slate-300 overflow-hidden relative">
              <div className={`transform transition-transform duration-100 ${spinning ? 'blur-md scale-110 translate-y-4' : 'scale-100'}`}>
                {symbol.icon}
              </div>
            </div>
          ))}
          {/* Shine effect */}
          <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/10 to-transparent pointer-events-none z-20"></div>
        </div>

        {/* Controls */}
        <div className="flex flex-col md:flex-row gap-6 justify-between items-center bg-slate-800/80 p-4 rounded-xl border border-white/10 backdrop-blur-sm relative z-10">
          <div className="flex items-center gap-4 bg-black/40 px-4 py-2 rounded-lg border border-white/5">
             <span className="text-slate-400 text-xs uppercase font-bold tracking-wider">Ставка</span>
             <div className="flex items-center gap-2">
                <button 
                  onClick={() => { playSound('click'); setBet(Math.max(10, bet - 10)); }}
                  disabled={spinning}
                  className="w-8 h-8 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white font-bold transition-colors"
                >-</button>
                <span className="text-yellow-400 font-mono text-xl w-16 text-center">${bet}</span>
                <button 
                  onClick={() => { playSound('click'); setBet(bet + 10); }}
                  disabled={spinning || bet >= balance}
                  className="w-8 h-8 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white font-bold transition-colors"
                >+</button>
             </div>
          </div>

          <div className="text-center min-w-[120px]">
             <div className="text-slate-400 text-[10px] uppercase font-bold mb-1">Выигрыш</div>
             <div className="text-green-400 font-mono text-2xl font-bold flex items-center justify-center gap-1 shadow-green-500/20 drop-shadow-sm">
               <Trophy size={16} /> ${lastWin}
             </div>
          </div>

          <button
            onClick={spin}
            disabled={spinning || balance < bet}
            className={`
              px-10 py-4 rounded-full font-bold text-lg uppercase tracking-widest transition-all shadow-xl flex items-center gap-2 border-b-4
              ${spinning || balance < bet 
                ? 'bg-slate-600 border-slate-800 text-slate-400 cursor-not-allowed' 
                : 'bg-gradient-to-b from-red-500 to-red-700 border-red-900 hover:from-red-400 hover:to-red-600 text-white hover:shadow-red-500/30 active:scale-95 active:border-b-0 active:translate-y-1'}
            `}
          >
            <RefreshCw className={`${spinning ? 'animate-spin' : ''}`} size={20} />
            КРУТИТЬ
          </button>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-4 gap-2 md:gap-4 w-full max-w-2xl text-slate-300">
        {SLOT_SYMBOLS.map(sym => (
            <div key={sym.id} className="bg-slate-900/80 p-2 rounded text-center border border-white/5 hover:bg-slate-800 transition-colors">
                <div className="text-2xl mb-1">{sym.icon}</div>
                <div className="text-[10px] md:text-xs text-slate-400">3x: <span className="text-yellow-400 font-bold">{sym.value}x</span></div>
            </div>
        ))}
      </div>
    </div>
  );
};

export default Slots;