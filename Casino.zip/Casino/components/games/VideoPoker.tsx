import React, { useState, useEffect } from 'react';
import { Card, GameType } from '../../types';
import { createDeck } from '../../constants';
import CardDisplay from '../CardDisplay';
import { ArrowLeft, RefreshCw, Play, GripVertical } from 'lucide-react';
import { playSound } from '../../utils/sound';
import { addToHistory } from '../../utils/storage';

interface VideoPokerProps {
  balance: number;
  updateBalance: (amount: number) => void;
  onBack: () => void;
}

type PokerPhase = 'betting' | 'dealing' | 'drawing' | 'result';

const HAND_RANKS = [
  { name: 'Роял Флеш', mult: 800 },
  { name: 'Стрит Флеш', mult: 50 },
  { name: 'Каре', mult: 25 },
  { name: 'Фулл Хаус', mult: 9 },
  { name: 'Флеш', mult: 6 },
  { name: 'Стрит', mult: 4 },
  { name: 'Сет (Тройка)', mult: 3 },
  { name: 'Две Пары', mult: 2 },
  { name: 'Пара (Валеты+)', mult: 1 },
];

const VideoPoker: React.FC<VideoPokerProps> = ({ balance, updateBalance, onBack }) => {
  const [deck, setDeck] = useState<Card[]>([]);
  const [hand, setHand] = useState<Card[]>([]);
  const [held, setHeld] = useState<boolean[]>([false, false, false, false, false]);
  const [phase, setPhase] = useState<PokerPhase>('betting');
  const [bet, setBet] = useState(5);
  const [message, setMessage] = useState('Сделайте ставку');
  const [winningHand, setWinningHand] = useState<string | null>(null);

  useEffect(() => {
    setDeck(createDeck());
  }, []);

  const evaluateHand = (cards: Card[]) => {
    const values = cards.map(c => c.numericValue === 1 ? 14 : c.numericValue).sort((a, b) => a - b);
    const suits = cards.map(c => c.suit);
    
    // Check counts
    const counts: Record<number, number> = {};
    values.forEach(v => counts[v] = (counts[v] || 0) + 1);
    const countValues = Object.values(counts).sort((a, b) => b - a);
    
    const isFlush = suits.every(s => s === suits[0]);
    const isStraight = values.every((v, i) => i === 0 || v === values[i - 1] + 1) || 
                       (values[0] === 2 && values[1] === 3 && values[2] === 4 && values[3] === 5 && values[4] === 14); // A-5 straight (Wheel)

    if (isFlush && isStraight && values[0] === 10) return { rank: 0, name: 'Роял Флеш' };
    if (isFlush && isStraight) return { rank: 1, name: 'Стрит Флеш' };
    if (countValues[0] === 4) return { rank: 2, name: 'Каре' };
    if (countValues[0] === 3 && countValues[1] === 2) return { rank: 3, name: 'Фулл Хаус' };
    if (isFlush) return { rank: 4, name: 'Флеш' };
    if (isStraight) return { rank: 5, name: 'Стрит' };
    if (countValues[0] === 3) return { rank: 6, name: 'Сет (Тройка)' };
    if (countValues[0] === 2 && countValues[1] === 2) return { rank: 7, name: 'Две Пары' };
    if (countValues[0] === 2) {
       // Jacks or Better check
       const pairValue = parseInt(Object.keys(counts).find(key => counts[parseInt(key)] === 2) || '0');
       // In our deck Ace is 11, J/Q/K are 10. Wait, createDeck uses Blackjack logic (10 for all face). 
       // We need actual poker values.
       // Let's rely on the `value` string 'J','Q','K','A' or '2'..'10'.
       // Map to poker values:
       const pokerVal = (str: string) => {
           if (str === 'A') return 14;
           if (str === 'K') return 13;
           if (str === 'Q') return 12;
           if (str === 'J') return 11;
           return parseInt(str);
       };
       // Re-evaluate counts using poker values logic for Jacks or Better
       const pValues = cards.map(c => pokerVal(c.value));
       const pCounts: Record<number, number> = {};
       pValues.forEach(v => pCounts[v] = (pCounts[v] || 0) + 1);
       const pairRank = parseInt(Object.keys(pCounts).find(k => pCounts[parseInt(k)] === 2) || '0');
       
       if (pairRank >= 11) return { rank: 8, name: 'Пара (Валеты+)' };
    }
    
    return null;
  };

  const deal = () => {
    if (balance < bet) {
        playSound('lose');
        return;
    }
    playSound('chip');
    updateBalance(-bet);
    const newDeck = createDeck();
    const newHand = [];
    for(let i=0; i<5; i++) newHand.push(newDeck.pop()!);
    
    setDeck(newDeck);
    setHand(newHand);
    setHeld([false, false, false, false, false]);
    setPhase('drawing');
    setMessage('Выберите карты, чтобы оставить');
    setWinningHand(null);
    playSound('card');
  };

  const toggleHold = (index: number) => {
    if (phase !== 'drawing') return;
    playSound('click');
    const newHeld = [...held];
    newHeld[index] = !newHeld[index];
    setHeld(newHeld);
  };

  const draw = () => {
    playSound('card');
    const currentDeck = [...deck];
    const currentHand = [...hand];
    
    // Replace unheld cards
    for(let i=0; i<5; i++) {
        if (!held[i]) {
            currentHand[i] = currentDeck.pop()!;
        }
    }
    
    setHand(currentHand);
    setDeck(currentDeck);
    
    const result = evaluateHand(currentHand);
    setPhase('result');
    let win = 0;
    
    if (result) {
        win = bet * HAND_RANKS[result.rank].mult;
        updateBalance(win);
        setMessage(`${result.name}! Вы выиграли $${win}`);
        setWinningHand(result.name);
        playSound('win');
    } else {
        setMessage('Без выигрыша');
        playSound('lose');
    }

    addToHistory({
        gameType: GameType.VIDEO_POKER,
        betAmount: bet,
        result: result ? result.name : 'Проигрыш',
        payout: win,
        balanceAfter: balance + win // Note: logic slightly flawed as balance prop isn't updated instantly here for tracking, but close enough for UX
    });
  };

  return (
    <div className="flex flex-col items-center w-full max-w-6xl mx-auto p-4 animate-in fade-in duration-500">
       <button onClick={() => { playSound('click'); onBack(); }} className="self-start mb-4 flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft size={20} /> Меню
      </button>

      <div className="w-full bg-blue-900 rounded-3xl p-6 md:p-10 border-4 border-blue-700 shadow-2xl relative overflow-hidden">
        {/* Screen Glare/Reflection */}
        <div className="absolute top-0 right-0 w-2/3 h-full bg-gradient-to-l from-white/5 to-transparent pointer-events-none"></div>

        {/* Paytable */}
        <div className="grid grid-cols-3 md:grid-cols-9 gap-2 mb-8 bg-blue-950/50 p-4 rounded-xl border border-blue-500/30">
            {HAND_RANKS.map((rank, i) => (
                <div key={i} className={`flex flex-col items-center p-2 rounded ${winningHand === rank.name ? 'bg-yellow-500 text-black animate-pulse' : 'bg-blue-900/50 text-blue-200'}`}>
                    <span className="text-[10px] uppercase font-bold text-center leading-tight h-8 flex items-center">{rank.name}</span>
                    <span className="font-mono font-bold text-lg">{rank.mult * bet}</span>
                </div>
            ))}
        </div>

        {/* Cards Area */}
        <div className="flex gap-2 md:gap-6 justify-center h-48 md:h-64 items-center mb-8 perspective-1000">
            {hand.length > 0 ? hand.map((card, i) => (
                <div key={i} className="relative group cursor-pointer" onClick={() => toggleHold(i)}>
                    <div className={`transition-transform duration-300 ${phase === 'drawing' && !held[i] ? 'hover:-translate-y-2' : ''}`}>
                         <CardDisplay card={card} className={`border-4 ${held[i] ? 'border-yellow-500 shadow-[0_0_15px_#eab308]' : 'border-transparent'}`} />
                    </div>
                    {phase === 'drawing' && (
                        <div className={`absolute -bottom-8 left-1/2 -translate-x-1/2 font-bold uppercase text-sm tracking-wider px-2 py-1 rounded ${held[i] ? 'bg-yellow-500 text-black' : 'text-transparent'}`}>
                            Оставить
                        </div>
                    )}
                </div>
            )) : (
                // Back of cards placeholder
                Array(5).fill(0).map((_, i) => (
                     <div key={i} className="w-24 h-36 bg-blue-800 rounded-lg border-2 border-blue-600/30 flex items-center justify-center">
                        <GripVertical className="text-blue-900/50" size={48} />
                     </div>
                ))
            )}
        </div>

        {/* Controls */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-black/40 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
             <div className="text-2xl font-bold font-serif text-yellow-400 text-center md:text-left flex-1">
                 {message}
             </div>

             <div className="flex items-center gap-6">
                 <div className="flex flex-col items-center">
                     <span className="text-blue-300 text-xs font-bold uppercase mb-1">Ставка</span>
                     <div className="flex items-center gap-2 bg-blue-950 rounded-lg p-1 border border-blue-700">
                         <button disabled={phase !== 'betting' && phase !== 'result'} onClick={() => { playSound('click'); setBet(Math.max(1, bet-1)); }} className="w-8 h-8 flex items-center justify-center bg-blue-800 hover:bg-blue-700 rounded text-white font-bold disabled:opacity-50">-</button>
                         <span className="font-mono w-12 text-center text-xl text-white">${bet}</span>
                         <button disabled={phase !== 'betting' && phase !== 'result'} onClick={() => { playSound('click'); setBet(bet+1); }} className="w-8 h-8 flex items-center justify-center bg-blue-800 hover:bg-blue-700 rounded text-white font-bold disabled:opacity-50">+</button>
                     </div>
                 </div>

                 {phase === 'drawing' ? (
                     <button onClick={draw} className="bg-yellow-500 hover:bg-yellow-400 text-black px-8 py-3 rounded-lg font-black uppercase text-xl shadow-lg transition-transform active:scale-95 flex items-center gap-2">
                         <RefreshCw /> Заменить
                     </button>
                 ) : (
                     <button onClick={deal} className="bg-green-600 hover:bg-green-500 text-white px-8 py-3 rounded-lg font-black uppercase text-xl shadow-lg transition-transform active:scale-95 flex items-center gap-2">
                         <Play fill="currentColor" /> Раздать
                     </button>
                 )}
             </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPoker;