import React, { useState, useMemo } from 'react';
import { ROULETTE_NUMBERS } from '../../constants';
import { RouletteNumber, GameType } from '../../types';
import { ArrowLeft } from 'lucide-react';
import { playSound } from '../../utils/sound';
import { addToHistory } from '../../utils/storage';

interface RouletteProps {
  balance: number;
  updateBalance: (amount: number) => void;
  onBack: () => void;
}

type BetType = 'red' | 'black' | 'even' | 'odd' | number | null;

const Roulette: React.FC<RouletteProps> = ({ balance, updateBalance, onBack }) => {
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<RouletteNumber | null>(null);
  const [betType, setBetType] = useState<BetType>(null);
  const [betAmount, setBetAmount] = useState(10);
  const [rotation, setRotation] = useState(0);
  const [history, setHistory] = useState<RouletteNumber[]>([]);

  // Generate gradient string dynamically to ensure visual matches data
  const wheelGradient = useMemo(() => {
    const segmentAngle = 360 / ROULETTE_NUMBERS.length;
    return ROULETTE_NUMBERS.map((n, i) => {
        const start = i * segmentAngle;
        const end = (i + 1) * segmentAngle;
        const color = n.color === 'red' ? '#ef4444' : n.color === 'black' ? '#0f172a' : '#16a34a';
        return `${color} ${start}deg ${end}deg`;
    }).join(', ');
  }, []);

  const placeBet = (type: BetType) => {
    if (spinning) return;
    playSound('chip');
    setBetType(type);
  };

  const spin = () => {
    if (!betType) return;
    if (balance < betAmount) {
        playSound('lose');
        return;
    }

    const currentBalance = balance - betAmount;
    updateBalance(-betAmount);
    playSound('spin');
    setSpinning(true);
    setResult(null);

    const winningIndex = Math.floor(Math.random() * ROULETTE_NUMBERS.length);
    const winner = ROULETTE_NUMBERS[winningIndex];

    // Calculate rotation to land on the winner
    // Index 0 is at 12 o'clock (0deg). Increasing index moves clockwise.
    // To land index i at 12 o'clock, we need to rotate the wheel such that index i is at 0deg (absolute).
    // The wheel rotates clockwise. 
    // Target position for index i relative to container 0 is: - (i * segmentSize)
    const segmentDeg = 360 / ROULETTE_NUMBERS.length;
    // We add a random jitter within the segment for realism (+/- 40% of segment)
    const jitter = (Math.random() - 0.5) * (segmentDeg * 0.8);
    
    // Calculate how much we need to rotate from 0 to get winning index to top
    // We want: (0 + rotation) - (index * deg) = 0 (mod 360) => rotation = index * deg
    // Wait, if wheel rotates clockwise (positive deg), index 0 moves to right. Index 36 (left of 0) moves to top.
    // So to get Index 1 to top, we need to rotate Counter-Clockwise? Or rotate almost 360 clockwise.
    // Let's visualize: 0 is Top. 1 is Right-ish. To get 1 to Top, rotate -9.7deg (CCW) or 350.3deg (CW).
    // So targetRotation = (360 - (index * segmentDeg)) % 360.
    
    const targetBaseRotation = (360 - (winningIndex * segmentDeg)); 
    
    // Current total rotation
    const currentRotation = rotation;
    // Normalize current to 0-360 to find where we are
    const currentMod = currentRotation % 360;
    
    // Calculate distance to target from current
    let distance = targetBaseRotation - currentMod;
    if (distance < 0) distance += 360; // Ensure we always spin forward
    
    // Add 5 full spins + distance + jitter
    const totalSpin = (360 * 5) + distance + jitter;
    const newRotation = currentRotation + totalSpin;

    setRotation(newRotation);

    setTimeout(() => {
        setResult(winner);
        setHistory(prev => [winner, ...prev].slice(0, 10));
        setSpinning(false);
        checkWin(winner, currentBalance);
    }, 3000);
  };

  const checkWin = (winner: RouletteNumber, balanceAfterBet: number) => {
    let win = false;
    let multiplier = 0;

    if (typeof betType === 'number') {
        if (winner.number === betType) {
            win = true;
            multiplier = 35;
        }
    } else if (betType === 'red' && winner.color === 'red') {
        win = true;
        multiplier = 2;
    } else if (betType === 'black' && winner.color === 'black') {
        win = true;
        multiplier = 2;
    } else if (betType === 'even' && winner.number !== 0 && winner.number % 2 === 0) {
        win = true;
        multiplier = 2;
    } else if (betType === 'odd' && winner.number !== 0 && winner.number % 2 !== 0) {
        win = true;
        multiplier = 2;
    }

    let payout = 0;
    if (win) {
        playSound('win');
        payout = betAmount * multiplier;
        updateBalance(payout);
    } else {
        playSound('lose');
    }

    addToHistory({
        gameType: GameType.ROULETTE,
        betAmount: betAmount,
        result: win ? 'Победа' : 'Проигрыш',
        payout: payout,
        balanceAfter: balanceAfterBet + payout,
        // Using Russian for UI consistency, but can be English
    });
  };

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-7xl mx-auto p-4 animate-in fade-in duration-500">
      <button onClick={() => { playSound('click'); onBack(); }} className="self-start mb-4 flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft size={20} /> Меню
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 w-full">
        
        {/* Wheel Section */}
        <div className="lg:col-span-1 flex flex-col items-center bg-slate-900 p-8 rounded-3xl shadow-2xl border border-slate-700 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
            
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 mb-8">
                 <div className="absolute inset-0 rounded-full border-[16px] border-[#3e2723] shadow-2xl"></div>
                 <div 
                    className="w-full h-full rounded-full border-4 border-[#d4af37] bg-slate-950 overflow-hidden relative transition-transform duration-[3000ms] cubic-bezier(0.25, 0.1, 0.25, 1)"
                    style={{ transform: `rotate(${rotation}deg)` }}
                 >
                    <div className="w-full h-full rounded-full opacity-90" style={{
                        background: `conic-gradient(${wheelGradient})`
                    }}></div>
                    <div className="absolute inset-0 m-auto w-3/4 h-3/4 bg-slate-900 rounded-full flex items-center justify-center border-4 border-[#b8860b]">
                        <div className="w-12 h-12 bg-gradient-to-br from-yellow-300 to-yellow-600 rounded-full shadow-lg"></div>
                    </div>
                 </div>
                 <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-2 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-yellow-400 z-10 drop-shadow-md"></div>
            </div>
            
            <div className="mt-4 flex flex-col items-center">
                <h3 className="text-slate-400 uppercase text-xs font-bold mb-2 tracking-widest">Результат</h3>
                {result ? (
                    <div className={`text-5xl font-bold font-mono px-8 py-4 rounded-xl border-2 shadow-lg ${result.color === 'red' ? 'bg-red-600 border-red-400' : result.color === 'black' ? 'bg-slate-900 border-slate-600' : 'bg-green-600 border-green-400'}`}>
                        {result.number}
                    </div>
                ) : (
                    <div className="text-5xl font-bold font-mono px-8 py-4 rounded-xl border-2 border-slate-700 text-slate-700">--</div>
                )}
            </div>
            
             <div className="mt-8 w-full">
                <h3 className="text-slate-500 uppercase text-xs font-bold mb-2 tracking-widest">История</h3>
                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                    {history.map((h, i) => (
                        <div key={i} className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shadow-md ${h.color === 'red' ? 'bg-red-600' : h.color === 'black' ? 'bg-black' : 'bg-green-600'}`}>
                            {h.number}
                        </div>
                    ))}
                </div>
            </div>
        </div>

        {/* Betting Board */}
        <div className="lg:col-span-2 bg-[#064e3b] p-8 rounded-3xl shadow-2xl border-[12px] border-[#3e2723] flex flex-col justify-between relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/felt.png')] opacity-30 pointer-events-none rounded-xl"></div>
            
            <div className="mb-6 flex flex-wrap gap-4 justify-between items-center bg-black/20 p-4 rounded-xl border border-white/5 backdrop-blur-sm z-10">
                <div className="flex items-center gap-4">
                     <span className="font-bold text-green-100 uppercase text-sm tracking-wider">Ваша ставка:</span>
                     {betType !== null ? (
                         <span className="bg-yellow-500 text-black px-4 py-1 rounded-full font-bold uppercase text-sm shadow-lg">
                             {typeof betType === 'number' ? `Число ${betType}` : 
                              betType === 'red' ? 'Красное' :
                              betType === 'black' ? 'Черное' :
                              betType === 'even' ? 'Чет' :
                              betType === 'odd' ? 'Нечет' : betType}
                         </span>
                     ) : <span className="text-white/50 italic text-sm">Нет ставки</span>}
                </div>
                 <div className="flex items-center gap-2">
                    <span className="text-xs uppercase font-bold text-green-200">Сумма:</span>
                    <input 
                        type="number" 
                        value={betAmount} 
                        onChange={(e) => setBetAmount(parseInt(e.target.value) || 0)}
                        className="w-24 bg-black/30 border border-green-500 rounded px-3 py-1 text-white text-right font-mono focus:outline-none focus:border-yellow-400"
                        min="1"
                        max={balance}
                    />
                </div>
            </div>

            {/* Numbers Grid */}
            <div className="grid grid-cols-12 gap-1 mb-6 z-10">
                 {/* 0 spans row */}
                 <button 
                    onClick={() => placeBet(0)}
                    className={`col-span-12 py-3 rounded border border-green-500/50 font-bold hover:brightness-110 transition-all ${betType === 0 ? 'ring-4 ring-yellow-400 z-10 shadow-lg scale-[1.02]' : ''} bg-green-600 text-white`}
                 >0</button>

                 {/* 1-36 */}
                 {ROULETTE_NUMBERS.filter(n => n.number !== 0).sort((a,b) => a.number - b.number).map((n) => (
                     <button
                        key={n.number}
                        onClick={() => placeBet(n.number)}
                        className={`
                            col-span-1 py-4 font-mono font-bold text-white rounded transition-all hover:scale-110 active:scale-95
                            ${n.color === 'red' ? 'bg-red-600' : 'bg-slate-900'}
                            ${betType === n.number ? 'ring-4 ring-yellow-400 z-10 scale-110 shadow-lg' : 'opacity-90 hover:opacity-100'}
                        `}
                     >
                         {n.number}
                     </button>
                 ))}
            </div>

            {/* Outside Bets */}
            <div className="grid grid-cols-4 gap-3 z-10">
                <button onClick={() => placeBet('even')} className={`py-4 bg-transparent border-2 border-green-400/30 text-green-100 uppercase font-bold tracking-wider rounded-lg hover:bg-green-700 transition-colors ${betType === 'even' ? 'bg-green-600 ring-4 ring-yellow-400' : ''}`}>Чет</button>
                <button onClick={() => placeBet('red')} className={`py-4 bg-red-600 text-white uppercase font-bold tracking-wider rounded-lg hover:bg-red-500 transition-colors ${betType === 'red' ? 'ring-4 ring-yellow-400' : ''}`}>Красное</button>
                <button onClick={() => placeBet('black')} className={`py-4 bg-slate-900 text-white uppercase font-bold tracking-wider rounded-lg hover:bg-slate-800 transition-colors ${betType === 'black' ? 'ring-4 ring-yellow-400' : ''}`}>Черное</button>
                <button onClick={() => placeBet('odd')} className={`py-4 bg-transparent border-2 border-green-400/30 text-green-100 uppercase font-bold tracking-wider rounded-lg hover:bg-green-700 transition-colors ${betType === 'odd' ? 'bg-green-600 ring-4 ring-yellow-400' : ''}`}>Нечет</button>
            </div>

            <button 
                onClick={spin}
                disabled={spinning || betType === null || balance < betAmount}
                className={`
                    mt-8 w-full font-black uppercase text-xl py-5 rounded-xl shadow-xl transition-all active:scale-[0.98] z-10 tracking-widest border-b-4
                    ${spinning || betType === null || balance < betAmount
                        ? 'bg-slate-700 text-slate-400 border-slate-900 cursor-not-allowed'
                        : 'bg-yellow-500 hover:bg-yellow-400 text-black border-yellow-700'
                    }
                `}
            >
                {spinning ? 'Крутим...' : 'СДЕЛАТЬ СТАВКУ'}
            </button>
        </div>

      </div>
    </div>
  );
};

export default Roulette;