import React, { useState, useEffect, useRef } from 'react';
import { GameType } from '../../types';
import { ArrowLeft, Rocket as RocketIcon, Flame, Trophy } from 'lucide-react';
import { playSound } from '../../utils/sound';
import { addToHistory } from '../../utils/storage';

interface RocketProps {
  balance: number;
  updateBalance: (amount: number) => void;
  onBack: () => void;
}

const Rocket: React.FC<RocketProps> = ({ balance, updateBalance, onBack }) => {
  const [bet, setBet] = useState(10);
  const [multiplier, setMultiplier] = useState(1.00);
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasCrashed, setHasCrashed] = useState(false);
  const [cashedOut, setCashedOut] = useState(false);
  const [cashedOutAt, setCashedOutAt] = useState(0);
  const [message, setMessage] = useState("Сделайте ставку");
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  const startTimeRef = useRef<number>(0);
  const crashPointRef = useRef<number>(0);

  // Game Loop
  const animate = (timestamp: number) => {
    if (!startTimeRef.current) startTimeRef.current = timestamp;
    const progress = timestamp - startTimeRef.current;
    
    // Calculate current multiplier based on time (exponential growth)
    // Formula: 1 + (time/1000)^2 * 0.1 (adjustable for speed)
    const newMult = 1 + Math.pow(progress / 1000, 2) * 0.1; 
    
    setMultiplier(parseFloat(newMult.toFixed(2)));
    drawGraph(newMult, false);

    if (newMult >= crashPointRef.current) {
      crash();
    } else {
      requestRef.current = requestAnimationFrame(animate);
    }
  };

  const drawGraph = (currentMult: number, isCrash: boolean) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.clearRect(0, 0, width, height);

    // Draw Grid
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for(let i=1; i<5; i++) {
        ctx.moveTo(0, height - (height/5)*i);
        ctx.lineTo(width, height - (height/5)*i);
    }
    ctx.stroke();

    // Calculate curve points
    // Map multiplier 1.0 -> 10.0 to canvas coordinates
    // We want dynamic scaling, but for simplicity let's fit 0-10s animation to width
    
    const rocketX = Math.min(width - 50, (currentMult - 1) * 40); // Simple linear x for demo
    const rocketY = height - Math.min(height - 50, (currentMult - 1) * 40); // Simple linear y

    // Draw Curve
    ctx.beginPath();
    ctx.moveTo(0, height);
    ctx.quadraticCurveTo(rocketX / 2, height, rocketX, rocketY);
    ctx.strokeStyle = isCrash ? '#ef4444' : '#eab308';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.lineTo(rocketX, height);
    ctx.lineTo(0, height);
    ctx.fillStyle = isCrash ? 'rgba(239, 68, 68, 0.2)' : 'rgba(234, 179, 8, 0.2)';
    ctx.fill();

    // Draw Rocket
    if (!isCrash) {
        ctx.save();
        ctx.translate(rocketX, rocketY);
        ctx.rotate(-45 * Math.PI / 180); // Tilt rocket
        ctx.font = '30px serif';
        ctx.fillText('🚀', -15, 0);
        ctx.restore();
    } else {
        // Draw Explosion
        ctx.font = '40px serif';
        ctx.fillText('💥', rocketX - 20, rocketY + 10);
    }
  };

  const startGame = () => {
    if (balance < bet) {
        setMessage("Недостаточно средств");
        playSound('lose');
        return;
    }

    playSound('click');
    updateBalance(-bet);
    
    // Generate crash point (Fair Crash Algorithm roughly)
    // 0.99 / (1 - Math.random())
    // 1% instant crash
    let crashPoint = (0.99 / (1 - Math.random()));
    if (crashPoint > 100) crashPoint = 100; // Cap at 100x for safety
    if (Math.random() < 0.01) crashPoint = 1.0; // 1% house edge instant crash
    
    crashPointRef.current = crashPoint;
    
    setIsPlaying(true);
    setHasCrashed(false);
    setCashedOut(false);
    setMultiplier(1.00);
    setMessage("Ракета запущена!");
    
    startTimeRef.current = 0;
    playSound('spin'); // Engine sound
    requestRef.current = requestAnimationFrame(animate);
  };

  const cashOut = () => {
    if (!isPlaying || hasCrashed || cashedOut) return;
    
    const winAmount = Math.floor(bet * multiplier);
    setCashedOut(true);
    setCashedOutAt(multiplier);
    updateBalance(winAmount);
    setMessage(`Вывод! +$${winAmount}`);
    playSound('win');
    
    addToHistory({
        gameType: GameType.ROCKET,
        betAmount: bet,
        result: `Вывод x${multiplier}`,
        payout: winAmount,
        balanceAfter: balance - bet + winAmount // approx
    });
  };

  const crash = () => {
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
    setIsPlaying(false);
    setHasCrashed(true);
    drawGraph(crashPointRef.current, true);
    
    if (!cashedOut) {
        setMessage(`Взрыв на x${crashPointRef.current.toFixed(2)}`);
        playSound('lose');
        addToHistory({
            gameType: GameType.ROCKET,
            betAmount: bet,
            result: 'Крушение',
            payout: 0,
            balanceAfter: balance // already deducted
        });
    }
  };

  useEffect(() => {
    return () => {
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-4xl mx-auto p-4 animate-in fade-in duration-500">
      <button onClick={() => { playSound('click'); onBack(); }} className="self-start mb-4 flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft size={20} /> Меню
      </button>

      <div className="bg-slate-900 w-full rounded-3xl p-6 border-4 border-slate-700 shadow-2xl relative">
        <div className="absolute top-4 left-6 flex gap-4 z-10">
            <div className="bg-black/40 px-4 py-2 rounded-lg border border-white/5">
                <span className="text-slate-400 text-xs uppercase font-bold">Текущий X</span>
                <div className={`text-4xl font-mono font-bold ${hasCrashed ? 'text-red-500' : 'text-yellow-400'}`}>
                    {multiplier.toFixed(2)}x
                </div>
            </div>
            {cashedOut && (
                 <div className="bg-green-900/40 px-4 py-2 rounded-lg border border-green-500/20 animate-pulse">
                    <span className="text-green-400 text-xs uppercase font-bold">Вы забрали</span>
                    <div className="text-2xl font-mono font-bold text-white">
                        {cashedOutAt.toFixed(2)}x
                    </div>
                </div>
            )}
        </div>

        <canvas 
            ref={canvasRef}
            width={800} 
            height={400} 
            className="w-full h-[300px] md:h-[400px] bg-slate-950 rounded-xl border border-white/10 shadow-inner"
        />

        <div className="mt-6 flex flex-col md:flex-row gap-6 items-center justify-between bg-black/20 p-6 rounded-2xl border border-white/5">
            <div className="flex flex-col gap-2 w-full md:w-auto">
                <label className="text-slate-400 text-xs font-bold uppercase">Ставка</label>
                <div className="flex items-center gap-2">
                     <button disabled={isPlaying} onClick={() => setBet(Math.max(10, bet - 10))} className="w-10 h-10 bg-slate-800 rounded text-white font-bold hover:bg-slate-700 disabled:opacity-50">-</button>
                     <input 
                        type="number" 
                        value={bet} 
                        onChange={(e) => setBet(parseInt(e.target.value) || 0)}
                        disabled={isPlaying}
                        className="bg-slate-950 border border-slate-700 h-10 w-24 text-center text-white font-bold rounded"
                     />
                     <button disabled={isPlaying} onClick={() => setBet(bet + 10)} className="w-10 h-10 bg-slate-800 rounded text-white font-bold hover:bg-slate-700 disabled:opacity-50">+</button>
                </div>
            </div>

            <div className="text-center">
                <div className={`text-lg font-bold ${cashedOut ? 'text-green-400' : hasCrashed ? 'text-red-500' : 'text-slate-300'}`}>
                    {message}
                </div>
            </div>

            <div className="w-full md:w-48">
                {!isPlaying || hasCrashed ? (
                    <button 
                        onClick={startGame} 
                        disabled={isPlaying && !hasCrashed}
                        className="w-full py-4 bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-400 hover:to-orange-500 text-black font-black uppercase text-xl rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2"
                    >
                        <RocketIcon size={24} /> Старт
                    </button>
                ) : (
                    <button 
                        onClick={cashOut}
                        disabled={cashedOut}
                        className={`w-full py-4 font-black uppercase text-xl rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2 ${cashedOut ? 'bg-slate-700 text-slate-500' : 'bg-green-500 hover:bg-green-400 text-black'}`}
                    >
                        <Trophy size={24} /> {cashedOut ? 'Забрал' : 'ЗАБРАТЬ'}
                    </button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default Rocket;